package in.kadam.familyrecords;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.database.*;
import android.database.sqlite.*;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.text.DateFormat;
import java.util.*;
import java.util.zip.*;

public class MainActivity extends Activity {
    private DB db;
    private LinearLayout root, content;
    private boolean marathi = false;
    private String currentModule = "Medicine";
    private final String[] modules = {"Medicine","Expenses","Vehicle Maintenance","Household Records","Family Medical Records","Documents"};
    private final String[] mrModules = {"औषधे","खर्च","वाहन देखभाल","घरगुती नोंदी","कुटुंब वैद्यकीय नोंदी","कागदपत्रे"};
    private static final int PICK_DOC = 41, CREATE_BACKUP = 42, RESTORE_BACKUP = 43;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        db = new DB(this);
        showHome();
    }
    private String tr(String en, String mr) { return marathi ? mr : en; }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density); }
    private TextView text(String s, int size) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setPadding(dp(12),dp(9),dp(12),dp(9)); return t;
    }
    private Button button(String s, Runnable r) {
        Button b = new Button(this); b.setText(s); b.setOnClickListener(v -> r.run()); return b;
    }
    private void showHome() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12),dp(10),dp(12),dp(8));
        root.addView(text("Kadam Family Record Manager", 22));
        LinearLayout bar = new LinearLayout(this);
        bar.addView(button(marathi ? "English" : "मराठी", () -> { marathi=!marathi; showHome(); }));
        bar.addView(button(tr("Backup","बॅकअप"), this::backup));
        bar.addView(button(tr("Restore","रिस्टोर"), this::restore));
        root.addView(bar);
        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content); root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
        for (int i=0;i<modules.length;i++) {
            final String m=modules[i];
            content.addView(button((marathi?mrModules[i]:modules[i])+"  ›", () -> openModule(m)));
        }
        content.addView(text(tr("All records are stored on this phone. No account or internet is required for normal use.",
                "सर्व नोंदी या फोनमध्ये साठवल्या जातात. सामान्य वापरासाठी खाते किंवा इंटरनेटची गरज नाही."),14));
    }
    private void openModule(String module) {
        currentModule=module;
        content.removeAllViews();
        content.addView(text(marathi ? mrModules[indexOf(module)] : module, 20));
        content.addView(button(tr("＋ Add record","＋ नोंद जोडा"), () -> addRecord(module)));
        if (module.equals("Documents")) content.addView(button(tr("＋ Import document","＋ कागदपत्र जोडा"), this::pickDocument));
        Cursor c=db.list(module);
        if (!c.moveToFirst()) content.addView(text(tr("No records yet.","अद्याप नोंदी नाहीत."),15));
        else do {
            long id=c.getLong(0); String title=c.getString(1), details=c.getString(2), date=c.getString(3);
            String amount=c.getString(4), file=c.getString(5);
            LinearLayout item=new LinearLayout(this); item.setOrientation(LinearLayout.VERTICAL);
            item.setPadding(dp(8),dp(5),dp(8),dp(5));
            item.addView(text(title,17));
            String extra=(details==null?"":details)+(amount==null||amount.isEmpty()?"":"\n₹ "+amount)+(date==null?"":"\n"+date)+(file==null?"":"\n"+file);
            item.addView(text(extra,13));
            LinearLayout actions=new LinearLayout(this);
            actions.addView(button(tr("Edit","बदला"), () -> editRecord(module,id,title,details,amount)));
            actions.addView(button(tr("Delete","हटवा"), () -> new AlertDialog.Builder(this)
                    .setMessage(tr("Delete this record?","ही नोंद हटवायची?"))
                    .setNegativeButton(tr("Cancel","रद्द"),null)
                    .setPositiveButton(tr("Delete","हटवा"),(d,w)->{db.delete(id);openModule(module);}).show()));
            item.addView(actions); content.addView(item);
            View line=new View(this); line.setBackgroundColor(0xffdddddd); content.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));
        } while(c.moveToNext());
        c.close();
        content.addView(button(tr("← Home","← मुख्यपृष्ठ"),this::showHome));
    }
    private int indexOf(String m) { for(int i=0;i<modules.length;i++) if(modules[i].equals(m)) return i; return 0; }
    private EditText field(String hint, String value) {
        EditText e=new EditText(this); e.setSingleLine(false); e.setHint(hint); if(value!=null)e.setText(value); return e;
    }
    private void addRecord(String module) { editRecord(module,-1,"","",""); }
    private void editRecord(String module,long id,String oldTitle,String oldDetails,String oldAmount) {
        LinearLayout box=new LinearLayout(this); box.setPadding(dp(12),0,dp(12),0); box.setOrientation(LinearLayout.VERTICAL);
        EditText title=field(tr("Title / Name","शीर्षक / नाव"),oldTitle);
        EditText details=field(tr("Details, usage, notes","तपशील, वापर, नोंदी"),oldDetails);
        EditText amount=field(tr("Amount (optional)","रक्कम (ऐच्छिक)"),oldAmount);
        box.addView(title); box.addView(details); box.addView(amount);
        new AlertDialog.Builder(this).setTitle(tr("Record","नोंद")).setView(box)
            .setNegativeButton(tr("Cancel","रद्द"),null)
            .setPositiveButton(tr("Save","जतन करा"),(d,w)->{
                String t=title.getText().toString().trim();
                if(t.isEmpty()){toast(tr("Title is required","शीर्षक आवश्यक आहे"));return;}
                db.save(id,module,t,details.getText().toString(),amount.getText().toString(),"");
                openModule(module);
            }).show();
    }
    private void pickDocument() {
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("*/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i,PICK_DOC);
    }
    @Override protected void onActivityResult(int request,int result,Intent data) {
        super.onActivityResult(request,result,data);
        if(result!=RESULT_OK||data==null)return;
        Uri uri=data.getData();
        try {
            if(request==PICK_DOC) {
                String name="document_"+System.currentTimeMillis();
                String mime=getContentResolver().getType(uri);
                File dir=new File(getFilesDir(),"documents"); dir.mkdirs();
                File out=new File(dir,name);
                try(InputStream in=getContentResolver().openInputStream(uri); OutputStream os=new FileOutputStream(out)) {
                    byte[] buf=new byte[8192]; int n; while((n=in.read(buf))>0)os.write(buf,0,n);
                }
                db.save(-1,"Documents",name,mime==null?"":mime,"",out.getAbsolutePath());
                openModule("Documents");
            } else if(request==CREATE_BACKUP) {
                try(OutputStream out=getContentResolver().openOutputStream(uri); ZipOutputStream zip=new ZipOutputStream(out)) {
                    addZip(zip,db.getDatabasePath("records.db"),"records.db");
                    File docs=new File(getFilesDir(),"documents"); if(docs.exists()) zipDir(zip,docs,"documents/");
                }
                toast(tr("Backup saved","बॅकअप जतन झाला"));
            } else if(request==RESTORE_BACKUP) {
                restoreZip(uri); db.close(); db=new DB(this); showHome();
                toast(tr("Backup restored","बॅकअप पुनर्संचयित झाला"));
            }
        } catch(Exception e) { toast(tr("Operation failed: ","क्रिया अयशस्वी: ")+e.getMessage()); }
    }
    private void backup() {
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT); i.setType("application/zip"); i.putExtra(Intent.EXTRA_TITLE,"KadamFamilyBackup.zip"); startActivityForResult(i,CREATE_BACKUP);
    }
    private void restore() {
        new AlertDialog.Builder(this).setMessage(tr("Restore replaces the current records. Continue?","रिस्टोर केल्यास सध्याच्या नोंदी बदलतील. पुढे जायचे?"))
            .setNegativeButton(tr("Cancel","रद्द"),null).setPositiveButton(tr("Choose backup","बॅकअप निवडा"),(d,w)->{
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("application/zip"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,RESTORE_BACKUP);
            }).show();
    }
    private void addZip(ZipOutputStream z,File f,String name)throws IOException {
        if(!f.exists())return; z.putNextEntry(new ZipEntry(name));
        try(FileInputStream in=new FileInputStream(f)){byte[]b=new byte[8192];int n;while((n=in.read(b))>0)z.write(b,0,n);} z.closeEntry();
    }
    private void zipDir(ZipOutputStream z,File dir,String prefix)throws IOException {
        File[] fs=dir.listFiles(); if(fs==null)return;
        for(File f:fs) if(f.isFile())addZip(z,f,prefix+f.getName());
    }
    private void restoreZip(Uri uri)throws IOException {
        File temp=new File(getCacheDir(),"restore.zip");
        try(InputStream in=getContentResolver().openInputStream(uri);OutputStream o=new FileOutputStream(temp)){byte[]b=new byte[8192];int n;while((n=in.read(b))>0)o.write(b,0,n);}
        db.close();
        try(ZipInputStream zin=new ZipInputStream(new FileInputStream(temp))){
            ZipEntry e; byte[] b=new byte[8192];
            while((e=zin.getNextEntry())!=null){
                File out;
                if(e.getName().equals("records.db")) out=getDatabasePath("records.db");
                else if(e.getName().startsWith("documents/")) { File dir=new File(getFilesDir(),"documents");dir.mkdirs();out=new File(dir,new File(e.getName()).getName()); }
                else continue;
                out.getParentFile().mkdirs(); try(FileOutputStream os=new FileOutputStream(out)){int n;while((n=zin.read(b))>0)os.write(b,0,n);}
                zin.closeEntry();
            }
        } finally { temp.delete(); }
    }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}

    static class DB extends SQLiteOpenHelper {
        DB(Context c){super(c,"records.db",null,1);}
        public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE records(id INTEGER PRIMARY KEY AUTOINCREMENT,module TEXT,title TEXT,details TEXT,date TEXT,amount TEXT,file_path TEXT)");}
        public void onUpgrade(SQLiteDatabase d,int a,int b){}
        void save(long id,String module,String title,String details,String amount,String path){
            SQLiteDatabase d=getWritableDatabase(); ContentValues v=new ContentValues();
            v.put("module",module);v.put("title",title);v.put("details",details);v.put("date",DateFormat.getDateInstance().format(new Date()));v.put("amount",amount);v.put("file_path",path);
            if(id<0)d.insert("records",null,v);else d.update("records",v,"id=?",new String[]{String.valueOf(id)});
        }
        Cursor list(String module){return getReadableDatabase().rawQuery("SELECT id,title,details,date,amount,file_path FROM records WHERE module=? ORDER BY id DESC",new String[]{module});}
        void delete(long id){getWritableDatabase().delete("records","id=?",new String[]{String.valueOf(id)});}
    }
}
