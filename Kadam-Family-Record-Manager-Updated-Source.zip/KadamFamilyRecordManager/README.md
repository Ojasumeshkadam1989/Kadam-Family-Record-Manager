# Kadam Family Record Manager

A starter native Android project written in Java. It is designed to work offline after installation and uses an on-device SQLite database.

## Included
- Medicine
- Expenses
- Vehicle Maintenance
- Household Records
- Family Medical Records
- Documents (imports a selected file into the app's private storage)
- English / Marathi interface toggle
- ZIP backup and restore (database plus imported documents)

## Important limitations
- This is a local record book, not a medical reminder or prescription system.
- The Vehicle Maintenance module has a dedicated fuel-entry form with date, odometer kilometres, CNG/Petrol selection, quantity (kg/litres), rate, automatically calculated total, fuel station/location, payment mode, and remarks. Fuel entries can be edited and deleted.
- The other record modules use general title/name, details/usage/notes and optional amount fields; their date is automatically set to the save date.
- The document list stores imported files privately; the current screen shows the stored filename and MIME type. A document preview/open feature is not yet included.
- The database was upgraded to version 2. Existing version 1 records are preserved when the app is updated; new vehicle fields are added during the database upgrade.
- Keep regular backups. Android uninstall or clearing app data can erase local records.
- The ZIP backup includes the database and files imported through the Documents module. Test a backup and restore with sample records before relying on it.
- The fuel form calculates the cost of each fill (quantity × rate). It does not yet calculate verified mileage or cost per kilometre across fill-ups.
- Family medical information is sensitive. Protect your phone with a screen lock and store backups securely.

## Build
This project uses Android Gradle Plugin 8.6.1, Gradle 8.7-compatible build configuration, Java 17, compile SDK 35, and min SDK 23.

Open the project root (the folder containing `settings.gradle`) in an Android Gradle IDE that supports Android Gradle Plugin 8.6.1 and Java 17. Allow Gradle to download the Android Gradle Plugin and Android SDK components when prompted. Then build the `app` module using the IDE's Build APK action.

If building directly on Android with Code on the Go, first confirm that your installed Code on the Go version supports Gradle Android projects, Java 17, and Android Gradle Plugin 8.6.1. If it does not, use the included GitHub Actions workflow to build the APK in the cloud from your phone.

## Install
After building, install `app/build/outputs/apk/debug/app-debug.apk` for testing. Android may ask you to allow installation from the browser or file manager that opened the APK.

## Cloud build from a phone (optional)
1. Create a GitHub repository from your phone and upload the project files.
2. The included `.github/workflows/android-apk.yml` workflow builds a debug APK on GitHub Actions.
3. Open the repository's Actions tab, open the latest successful run, and download the `KadamFamilyRecordManager-debug-apk` artifact.
4. Extract the downloaded artifact ZIP and install the APK.

A debug APK is suitable for personal testing. For long-term distribution, generate and securely store your own signing key and build a signed release APK.
